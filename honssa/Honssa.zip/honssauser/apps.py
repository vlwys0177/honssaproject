from django.apps import AppConfig


class HonssauserConfig(AppConfig):
    name = 'honssauser'
