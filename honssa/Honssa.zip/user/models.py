from django.db import models
from django.urls import reverse
from admin.models import *

# Create your models here.